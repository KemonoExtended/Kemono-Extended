Steps to build:
Install webpack using "npm install --save-dev webpack"
Run "Webpack"